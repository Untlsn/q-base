<?php require './partial/header.php' ?>
<main class="main">
  <?php require './partial/search-bar.php' ?>
  <?php require './partial/q-bars.php' ?>
</main>
<script src="https://kit.fontawesome.com/2d55a3e5cd.js" crossorigin="anonymous"></script>