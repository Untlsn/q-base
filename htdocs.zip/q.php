<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="./style/css/q-style.css" />
  <title>Main</title>
  <?php
    require './php/index-code.php';
    require './php/my-sql-n.php';
    require './php/q-code.php';
    $mysql = new MySqlN();
    $qId = @$_GET['q-id'];
    $jsonData = json_decode(
      file_get_contents(
        "./q-json/$qId.json"
      ), true
    );

    $creator = new qCreator($jsonData)
  ?>
</head>
<body>
  <?php require './partial/header.php' ?>
  <main>
    <?=$creator->createQuestions()?>
    <div class="result">
      <span class="result__score"> Twój wynik: <span class="score">?</span>/<?=count($jsonData['questions'])?></span>
      <div class="result__img" style="background-image: url(./img/for-q/<?=$jsonData['resultImg']?>)"></div>
    </div>
  </main>
  <script>qId = <?= $qId ?></script>
  <script src="javascript/q-script.js"></script>
</body>
</html>