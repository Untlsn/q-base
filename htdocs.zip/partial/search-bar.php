<form action="./search.php" method="GET" class="search-bar">
  <input type="text" placeholder="Szukaj Q..." class="search-bar__input search-bar__input--search" name="search">
  <input type="submit" value="SZUKAJ" class="search-bar__input search-bar__input--submit">
  <div class="search-bar__exit">X</div>
</form>
<script>
  const searchBar = document.querySelector('.search-bar')
  document.querySelector('.header__button--search').addEventListener('click', () => {
    searchBar.classList.add('search-bar--visible')
  })
  document.querySelector('.search-bar__exit').addEventListener('click', () => {
    searchBar.classList.remove('search-bar--visible')
  })
</script>