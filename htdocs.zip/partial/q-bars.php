<div class="q-bars-wrapper">
  <atricle class="q-bar q-bar--1">
    <?php $indexCode->createQBar(0, 10) ?>
  </atricle>
  <atricle class="q-bar q-bar--2">
    <?php $indexCode->createQBar(1, 10) ?>  
  </atricle>
</div>